# Code folding is recommended to read this code.
# TODO: make diagram of the rough philosophy of how the pie menu is organized.
# Depends on other add-ons: PolyQuilt (for its delete tool), 3D hair brush (for groom brushes), GPTools for (time scrubber), Anim Reviewer (for playblasts)

# TODO / ideas:
# Annotation tool? Measure tool? Repeat action? (could fit in undo menu, if I'm willing to drag a lil further to undo)
# Wireframe/xray/materialpreview/render pie? Maybe for object mode pie only? (could fit in undo menu)
# Think about how you could use global vars here. E.g. I could have an editmode op take you to sculptmode, but, keep the "effective mode" in a global var still being EDIT mode, s.t. when you activate the pie menu in this pseudo-sculptmode it actully still shows the editmode pie menu, and anything you select there will automatically send you back to edit mode. Y'know, for quick convenient dips into other modes.

import bpy
import time
from math import sqrt, atan2, pi
from bpy.types import Menu, Operator
from bpy_extras import view3d_utils
from mathutils import Vector, Quaternion

# -=- Common bits -=-
# --- ↑ Mode ↑ ---
class VIEW3D_OT_spawn_modepie_then_spawn_mainpie(Operator):
    bl_idname = 'view3d.spawn_modepie_then_spawn_mainpie'
    bl_label=''
    def execute(self,C): pass
        # TODO: the purpose of this is to make the modes always be in the same direction s.t. gestures can be consistent.
        # pie.operator('wm.call_menu_pie', text='Mode').name = 'VIEW3D_MT_object_mode_pie'

# --- ↗ Undo ↗ ---
class VIEW3D_OT_undo_then_spawn_undopie1(Operator):
    bl_idname = 'view3d.undo_then_spawn_undopie1'
    bl_label = ''
    def execute(self,C):
        try: bpy.ops.ed.undo()
        except RuntimeError: pass # No more steps to undo
        bpy.ops.wm.call_menu_pie(name='VIEW3D_MT_SUBPIE_undopie1')
        return {'FINISHED'}
class VIEW3D_OT_undo_then_spawn_undopie2(Operator):
    bl_idname = 'view3d.undo_then_spawn_undopie2'
    bl_label = ''
    def execute(self,C):
        try: bpy.ops.ed.undo()
        except RuntimeError: pass # No more steps to undo
        bpy.ops.wm.call_menu_pie(name='VIEW3D_MT_SUBPIE_undopie2')
        return {'FINISHED'}
class VIEW3D_OT_redo_then_spawn_redopie1(Operator):
    bl_idname = 'view3d.redo_then_spawn_redopie1'
    bl_label = ''
    def execute(self,C):
        try: bpy.ops.ed.redo()
        except RuntimeError: pass # No more steps to redo
        bpy.ops.wm.call_menu_pie(name='VIEW3D_MT_SUBPIE_redopie1')
        return {'FINISHED'}
class VIEW3D_OT_redo_then_spawn_redopie2(Operator):
    bl_idname = 'view3d.redo_then_spawn_redopie2'
    bl_label = ''
    def execute(self,C):
        try: bpy.ops.ed.redo()
        except RuntimeError: pass # No more steps to redo
        bpy.ops.wm.call_menu_pie(name='VIEW3D_MT_SUBPIE_redopie2')
        return {'FINISHED'}
class VIEW3D_OT_redo_last_then_spawn_redolastpie1(Operator):
    bl_idname = 'view3d.redo_last_then_spawn_redolastpie1'
    bl_label = ''
    def execute(self,C):
        try: bpy.ops.screen.redo_last()
        except RuntimeError: pass # No steps to redo
        bpy.ops.wm.call_menu_pie(name='VIEW3D_MT_SUBPIE_redolastpie1')
        return {'FINISHED'}
class VIEW3D_OT_redo_last_then_spawn_redolastpie2(Operator):
    bl_idname = 'view3d.redo_last_then_spawn_redolastpie2'
    bl_label = ''
    def execute(self,C):
        try: bpy.ops.screen.redo_last()
        except RuntimeError: pass # No steps to redo
        bpy.ops.wm.call_menu_pie(name='VIEW3D_MT_SUBPIE_redolastpie2')
        return {'FINISHED'}
class VIEW3D_OT_duplicate(Operator):
    bl_idname = 'view3d.duplicate'
    bl_label  = ''
    def execute(self,C):
        print('spacedatatype',C.space_data.type)
        match C.space_data.type:
            case 'VIEW_3D':
                match C.mode:
                    case 'OBJECT': bpy.ops.object.duplicate_move('INVOKE_DEFAULT')
                    case 'EDIT'  : bpy.ops.  mesh.duplicate_move('INVOKE_DEFAULT')
                    # TODO: case ...
                    case _: pass
            case 'NODE_EDITOR':    bpy.ops.  node.duplicate_move('INVOKE_DEFAULT')
            # TODO: case ...
            case _: pass
        return {'FINISHED'}

class VIEW3D_MT_SUBPIE_historypie(Menu):
    bl_label = ''
    def draw(self,C):
        pie = self.layout.menu_pie()
        pie.separator()                                                                                 # ←
        pie.separator()                                                                                 # →
        pie.operator('view3d.duplicate',                        text='Duplicate', icon='DUPLICATE')     # ↓
        pie.separator()                                                                                 # ↑
        pie.operator('view3d.redo_then_spawn_redopie1',         text='Redo',      icon='LOOP_FORWARDS') # ↖
        pie.operator('view3d.undo_then_spawn_undopie1',         text='Undo',      icon='LOOP_BACK'    ) # ↗
        pie.operator('view3d.redo_last_then_spawn_redolastpie1', text='Last',      icon='RECOVER_LAST' ) # ↙
        pie.operator('view3d.redo_then_spawn_redopie2',         text='Redo',      icon='LOOP_FORWARDS') # ↘

class VIEW3D_MT_SUBPIE_undopie1(Menu):
    bl_label = ''
    def draw(self,C):
        pie = self.layout.menu_pie()
        pie.separator()                                                                    # ←
        pie.separator()                                                                    # →
        pie.separator()                                                                    # ↓
        pie.separator()                                                                    # ↑
        pie.operator('view3d.redo_then_spawn_redopie1', text='Redo', icon='LOOP_FORWARDS') # ↖
        pie.separator()                                                                    # ↗
        pie.operator('view3d.undo_then_spawn_undopie2', text='Undo', icon='LOOP_BACK'    ) # ↙
        pie.operator('view3d.redo_then_spawn_redopie2', text='Redo', icon='LOOP_FORWARDS') # ↘
class VIEW3D_MT_SUBPIE_undopie2(Menu):
    bl_label = ''
    def draw(self,C):
        pie = self.layout.menu_pie()
        pie.separator()                                                                    # ←
        pie.separator()                                                                    # →
        pie.separator()                                                                    # ↓
        pie.separator()                                                                    # ↑
        pie.operator('view3d.redo_then_spawn_redopie1', text='Redo', icon='LOOP_FORWARDS') # ↖
        pie.operator('view3d.undo_then_spawn_undopie1', text='Undo', icon='LOOP_BACK'    ) # ↗
        pie.separator()                                                                    # ↙
        pie.operator('view3d.redo_then_spawn_redopie2', text='Redo', icon='LOOP_FORWARDS') # ↘
class VIEW3D_MT_SUBPIE_redopie1(Menu):
    bl_label = ''
    def draw(self,C):
        pie = self.layout.menu_pie()
        pie.separator()                                                                    # ←
        pie.separator()                                                                    # →
        pie.separator()                                                                    # ↓
        pie.separator()                                                                    # ↑
        pie.separator()                                                                    # ↖
        pie.operator('view3d.undo_then_spawn_undopie1', text='Undo', icon='LOOP_BACK'    ) # ↗
        pie.operator('view3d.undo_then_spawn_undopie2', text='Undo', icon='LOOP_BACK'    ) # ↙
        pie.operator('view3d.redo_then_spawn_redopie2', text='Redo', icon='LOOP_FORWARDS') # ↘
class VIEW3D_MT_SUBPIE_redopie2(Menu):
    bl_label = ''
    def draw(self,C):
        pie = self.layout.menu_pie()
        pie.separator()                                                                    # ←
        pie.separator()                                                                    # →
        pie.separator()                                                                    # ↓
        pie.separator()                                                                    # ↑
        pie.operator('view3d.redo_then_spawn_redopie1', text='Redo', icon='LOOP_FORWARDS') # ↖
        pie.operator('view3d.undo_then_spawn_undopie1', text='Undo', icon='LOOP_BACK'    ) # ↗
        pie.operator('view3d.undo_then_spawn_undopie2', text='Undo', icon='LOOP_BACK'    ) # ↙
        pie.separator()                                                                    # ↘
class VIEW3D_MT_SUBPIE_redolastpie1(Menu):
    bl_label = ''
    def draw(self,C):
        pie = self.layout.menu_pie()
        pie.separator()                                                                           # ←
        pie.separator()                                                                           # →
        pie.separator()                                                                           # ↓
        pie.separator()                                                                           # ↑
        pie.separator()                                                                           # ↖
        pie.operator('vew3d.redo_last_then_spawn_redolastpie2', text='Last', icon='RECOVER_LAST') # ↗
        pie.separator()                                                                           # ↙
        pie.separator()                                                                           # ↘
class VIEW3D_MT_SUBPIE_redolastpie2(Menu):
    bl_label = ''
    def draw(self,C):
        pie = self.layout.menu_pie()
        pie.separator()                                                                            # ←
        pie.separator()                                                                            # →
        pie.separator()                                                                            # ↓
        pie.separator()                                                                            # ↑
        pie.separator()                                                                            # ↖
        pie.separator()                                                                            # ↗
        pie.operator('vew3d.redo_last_then_spawn_redolastpie1', text='Last', icon='RECOVER_LAST' ) # ↙
        pie.separator()                                                                            # ↘

# --- → Transform → ---
# Note I edited my keymap so the Rotate tool activates trackball instead of typical rotate.
class VIEW3D_OT_select_tf_tool_then_spawn_orientpie(Operator):
    bl_idname = 'view3d.select_tf_tool_then_spawn_orientpie'
    bl_label = ''
    def execute(self,C):
        bpy.ops.wm.tool_set_by_id(name='builtin.select', as_fallback=True)
        bpy.ops.wm.tool_set_by_id(name='builtin.transform')
        bpy.ops.wm.call_menu_pie(name='VIEW3D_MT_SUBPIE_orientpie')
        return {'FINISHED'}
class VIEW3D_OT_set_scene_orientation_then_spawn_pivotpie(Operator):
    bl_idname = 'view3d.set_scene_orientation_then_spawn_pivotpie'
    bl_label = ''
    orientation: bpy.props.EnumProperty(items=[
         ('GLOBAL', 'Global', ''),
         ('LOCAL' , 'Local' , ''),
         ('NORMAL', 'Normal', ''),
         ('GIMBAL', 'Gimbal', ''),
         ('VIEW'  , 'View'  , ''),
         ('CURSOR', 'Cursor', ''),
         ('PARENT', 'Parent', ''),
         ('CUSTOM', 'Custom', ''),
    ])
    def execute(self,C):
        # Note: You want a subpie enumerating the custom orientatinos? You have to do s/t stupid b/c custom orientations' names not easily gettable: https://blender.stackexchange.com/a/196080
        C.scene.transform_orientation_slots[0].type = self.orientation
        bpy.ops.wm.call_menu_pie(name='VIEW3D_MT_SUBPIE_pivotpie')
        return {'FINISHED'}
class VIEW3D_OT_set_scene_pivot(bpy.types.Operator):
    bl_idname = 'view3d.set_scene_pivot'
    bl_label = ''
    pivot: bpy.props.EnumProperty(items=[
        ('BOUNDING_BOX_CENTER', "Bounding Box Center", ""),
        ('CURSOR',             "3D Cursor", ""),
        ('INDIVIDUAL_ORIGINS', "Individual Origins", ""),
        ('MEDIAN_POINT',       "Median Point", ""),
        ('ACTIVE_ELEMENT',     "Active Element", ""),
    ])
    def execute(self, context):
        context.scene.tool_settings.transform_pivot_point = self.pivot
        return {'FINISHED'}
class VIEW3D_MT_SUBPIE_orientpie(Menu):
    bl_label = ''
    def draw(self,C):
        pie = self.layout.menu_pie()
        pie.operator('view3d.set_scene_orientation_then_spawn_pivotpie', text='Local',  icon='ORIENTATION_LOCAL' ).orientation = 'LOCAL'  # ← Local
        pie.operator('view3d.set_scene_orientation_then_spawn_pivotpie', text='Global', icon='ORIENTATION_GLOBAL').orientation = 'GLOBAL' # → Global
        pie.operator('transform.select_orientation',                     text='Custom', icon='ORIENTATION_GLOBAL')                        # ↓ Custom
        pie.operator('view3d.set_scene_orientation_then_spawn_pivotpie', text='Normal', icon='ORIENTATION_NORMAL').orientation = 'NORMAL' # ↑ Normal
        pie.operator('view3d.set_scene_orientation_then_spawn_pivotpie', text='Parent', icon='ORIENTATION_PARENT').orientation = 'PARENT' # ↖ Parent
        pie.operator('view3d.set_scene_orientation_then_spawn_pivotpie', text='Cursor', icon='ORIENTATION_CURSOR').orientation = 'CURSOR' # ↗ Cursor
        pie.operator('view3d.set_scene_orientation_then_spawn_pivotpie', text='Gimbal', icon='ORIENTATION_GIMBAL').orientation = 'GIMBAL' # ↙ Gimbal
        pie.operator('view3d.set_scene_orientation_then_spawn_pivotpie', text='View',   icon='ORIENTATION_VIEW'  ).orientation = 'VIEW'   # ↘ View
class VIEW3D_MT_SUBPIE_pivotpie(Menu):
    bl_label = 'pivot'
    def draw(self, context):
        pie = self.layout.menu_pie()
        pie.operator('view3d.set_scene_pivot', text='Bounding Box Center').pivot = 'BOUNDING_BOX_CENTER' # ←
        pie.operator('view3d.set_scene_pivot', text='3D Cursor'          ).pivot = 'CURSOR'              # →
        pie.operator('view3d.set_scene_pivot', text='Individual Origins' ).pivot = 'INDIVIDUAL_ORIGINS'  # ↓
        pie.operator('view3d.set_scene_pivot', text='Median Point'       ).pivot = 'MEDIAN_POINT'        # ↑
        pie.operator('view3d.set_scene_pivot', text='Active Element'     ).pivot = 'ACTIVE_ELEMENT'      # ↖
        pie.separator()                                                                                  # ↗
        pie.separator()                                                                                  # ↙
        pie.separator()                                                                                  # ↘

# --- ↘ Selection, Snapping ↘ ---
class VIEW3D_OT_set_snap_target(Operator):
    bl_idname = 'view3d.set_snap_target'
    bl_label = ''
    snap_target: bpy.props.EnumProperty(items=[
       ('NONE', '', ''),
       ('INCREMENT', '', ''),
       ('GRID', '', ''),
       ('VERTEX', '', ''),
       ('EDGE', '', ''),
       ('FACE', '', ''),
       ('VOLUME', '', ''),
       ('FACE_PROJECT', '', ''),
       ('FACE_NEAREST', '', ''),
    ])
    def execute(self,C):
        bpy.context.scene.tool_settings.use_snap = True
        if self.snap_target in ['FACE_PROJECT','FACE_NEAREST']: C.scene.tool_settings.snap_elements_individual = {self.snap_target}
        else                                                  : C.scene.tool_settings.snap_elements_base       = {self.snap_target}
        return {'FINISHED'}
class VIEW3D_OT_set_selection_tool(Operator):
    # Selecting a tool is simple as wm.tool_set_by_id. But setting the active tool's mode is a bit of a song and dance.
    bl_idname = 'view3d.set_selection_tool'
    bl_label = ''
    tool: bpy.props.StringProperty()
    mode: bpy.props.StringProperty()
    def execute(self,C):
        bpy.ops.wm.tool_set_by_id(name=self.tool)
        tool = C.workspace.tools.from_space_view3d_mode(C.mode, create=False)
        props = tool.operator_properties('view3d.select_box')   if self.tool=='builtin.select_box' \
           else tool.operator_properties('view3d.select_lasso') if self.tool=='builtin.select_lasso' \
           else tool.operator_properties('view3d.select_circle')
        props.mode = self.mode
        return {'FINISHED'}
class VIEW3D_OT_select_circle_tool_then_spawn_selectionpie1(Operator):
    bl_idname = 'view3d.select_circle_tool_then_spawn_selectionpie1'
    bl_label = ''
    def execute(self,C):
        bpy.ops.wm.tool_set_by_id(name='builtin.select_circle', as_fallback=True)
        bpy.ops.wm.call_menu_pie(name='VIEW3D_MT_SUBPIE_selectionpie1')
        return {'FINISHED'}
class VIEW3D_OT_toggle_snapping_then_spawn_magnetpie(Operator):
    bl_idname = 'view3d.toggle_snapping_then_spawn_magnetpie'
    bl_label = ''
    def execute(self,C):
        C.scene.tool_settings.use_snap = not C.scene.tool_settings.use_snap
        bpy.ops.wm.call_menu_pie(name='VIEW3D_MT_SUBPIE_magnetpie')
        return {'FINISHED'}
#class VIEW3D_OT_grow_selection_then_spawn_growselectionmenu1(Operator): TODO
#class VIEW3D_OT_grow_selection_then_spawn_growselectionmenu2(Operator): TODO
class VIEW3D_MT_SUBPIE_selectionpie1(Menu):
    # TODO:
    #   In editmode, select similar / by normal direction etc.
    #   Add grow selection recursive subpie (useful in both edit+pose modes is why it may deserve a place here)
    #     ↙ Feels good for the grow/shrink selection menu, b/c it's diagonal direction for ez swiping.
    #     ← Hiding menu
    bl_label = ''
    def draw(self,C):
        pie = self.layout.menu_pie()
        if C.mode=='EDIT_MESH': pie.operator('mesh.select_edge_loop_multi')                                       # ← Loop
        else                  : pie.separator()
        pie.separator()                                                                                           # →
        pie.operator('wm.call_menu_pie', text='Snap').name = 'VIEW3D_MT_snap_pie'                                 # ↓ Snap to cursor/origin # TODO: remake this pie custom, w/ only the options you need, and recursive, so you can quickly snap cusror to origin then immediately snap object to cusror.
        pie.operator('view3d.toggle_snapping_then_spawn_magnetpie', icon='SNAP_ON')                               # ↑ Snap targets
        if   C.mode=='POSE'              : pie.operator(         'pose.select_all', text='Inv').action = 'INVERT' # ↖ Invert (doubles as select all)
        elif C.mode=='OBJECT'            : pie.operator(       'object.select_all', text='Inv').action = 'INVERT'   
        elif C.mode=='EDIT_MESH'         : pie.operator(         'mesh.select_all', text='Inv').action = 'INVERT'
        elif C.mode=='EDIT_CURVES'       : pie.operator(       'curves.select_all', text='Inv').action = 'INVERT'
        elif C.mode=='EDIT_ARMATURE'     : pie.operator(     'armature.select_all', text='Inv').action = 'INVERT'
        elif C.mode=='EDIT_GREASE_PENCIL': pie.operator('grease_pencil.select_all', text='Inv').action = 'INVERT'
        else                             : pie.separator()
        pie.separator()                                                                                           # ↗
        pie.separator()                                                                                           # ↙ Grow/shrink
        if   C.mode=='POSE'              : pie.operator(         'pose.select_linked', text='Inv')                # ↘ Linked
        elif C.mode=='OBJECT'            : pie.operator(       'object.select_linked', text='Inv')   
        elif C.mode=='EDIT_MESH'         : pie.operator(         'mesh.select_linked', text='Inv')
        elif C.mode=='EDIT_CURVES'       : pie.operator(       'curves.select_linked', text='Inv')
        elif C.mode=='EDIT_ARMATURE'     : pie.operator(     'armature.select_linked', text='Inv')
        elif C.mode=='EDIT_GREASE_PENCIL': pie.operator('grease_pencil.select_linked', text='Inv')
        else                             : pie.separator()
class VIEW3D_MT_SUBPIE_magnetpie(Menu):
    bl_label = ''
    def draw(self, context):
        pie = self.layout.menu_pie()
        pie.operator('view3d.set_snap_target', text='Increment'   ).snap_target = 'INCREMENT'    # ← Increment
        pie.operator('view3d.set_snap_target', text='Grid'        ).snap_target = 'GRID'         # → Grid
        pie.operator('view3d.set_snap_target', text='Vertex'      ).snap_target = 'VERTEX'       # ↓ Vertex
        pie.operator('view3d.set_snap_target', text='Edge'        ).snap_target = 'EDGE'         # ↑ Edge
        pie.operator('view3d.set_snap_target', text='Face'        ).snap_target = 'FACE'         # ↖ Face
        pie.operator('view3d.set_snap_target', text='Volume'      ).snap_target = 'VOLUME'       # ↗ Volume
        pie.operator('view3d.set_snap_target', text='Face Project').snap_target = 'FACE_PROJECT' # ↙ Face Project
        pie.operator('view3d.set_snap_target', text='Face Nearest').snap_target = 'FACE_NEAREST' # ↘ Face Nearest

# --- ↓ View options ↓ ---
class VIEW3D_OT_unset_set_render_border(Operator):
    bl_idname = 'view3d.unset_set_render_border'
    bl_label = ''
    def execute(self,C):
        bpy.ops.view3d.clear_render_border()
        bpy.ops.view3d.render_border('INVOKE_DEFAULT')
        return {'FINISHED'}
class VIEW3D_MT_SUBPIE_areapie(Menu):
    bl_label = ''
    def draw(self,C):
        pie = self.layout.menu_pie()
        pie.operator('wm.context_toggle',      text='',icon='MENU_PANEL'      ).data_path = 'space_data.show_region_toolbar'     # ← Tool panel
        pie.operator('wm.context_toggle',      text='',icon='MOD_TRIANGULATE' ).data_path = 'space_data.show_region_ui'          # → Side Panel
        pie.operator('screen.screen_full_area',text='',icon='FULLSCREEN_ENTER').use_hide_panels = True                           # ↓ Fullscren zen mode
        pie.operator('screen.area_join',       text='',icon='AREA_JOIN'       )                                                  # ↑ Join/Split/Replace areas
        pie.operator('wm.context_toggle',      text='',icon='TOOL_SETTINGS'   ).data_path = 'space_data.show_region_tool_header' # ↖ Tool settings
        pie.operator('wm.tool_set_by_id',      text='',icon='GREASEPENCIL'    ).name      = 'builtin.annotate'                   # ↗ Anno (it's here because this subpie is common to many areas)
        pie.operator('screen.region_quadview', text='',icon='KEY_WINDOWS'     )                                                  # ↙ Quad
        pie.operator('wm.context_toggle',      text='',icon='ASSET_MANAGER'   ).data_path = 'space_data.show_region_asset_shelf' # ↘ Asset shelf
class VIEW3D_MT_SUBPIE_camerapie(Menu):
    bl_label = ''
    def draw(self,C):
        pie = self.layout.menu_pie()
        pie.operator     ('view3d.view_camera',    text='',icon='VIEW_CAMERA'  )                        # ← View to camera
        pie.operator     ('view3d.camera_to_view', text='',icon='CAMERA_STEREO')                        # → Camera to view
        pie.operator     ('view3d.view_persportho',text='',icon='VIEW_ORTHO'   )                        # ↓ Ortho
        op = pie.operator('view3d.view_axis',      text='',icon='AXIS_TOP'     )                        # ↑ Align view to normal (and automatically activate ortho mode maybe?)
        op.align_active = True                                                                          #
        op.type         = 'TOP'                                                                         #
        pie.separator    ()                                                                             # ↖
        pie.operator     ('view3d.localview',      text='',icon='ZOOM_SELECTED').frame_selected  = True # ↗ Solo and frame selected TODO: in armature edit mode, just hide others.
        pie.operator     ('view3d.view_selected',  text='',icon='VIEWZOOM'     ).use_all_regions = True # ↙ Frame selected
        pie.separator()                                                                                 # ↘
class VIEW3D_MT_SUBPIE_shadingpie(Menu):
    bl_label = ''
    def draw(self,C):
        pie = self.layout.menu_pie()
        pie.operator('view3d.unset_set_render_border',text='',icon='LIGHT_AREA'      )                                                  # ← Render region
        pie.operator('view3d.toggle_shading',         text='',icon='SHADING_TEXTURE' ).type      = 'MATERIAL'                           # → Material preview
        pie.operator('view3d.toggle_shading',         text='',icon='SHADING_WIRE'    ).type      = 'WIREFRAME'                          # ↓ Wire # TODO: I never use this since X-ray exists. Replace w/ s/t else?
        pie.operator('view3d.clip_border',            text='',icon='MOD_SOLIDIFY'    )                                                  # ↑ Clipping region
        pie.operator('wm.context_toggle',             text='',icon='EDITMODE_HLT'    ).data_path = 'space_data.overlay.show_retopology' # ↖ Editmode retopo overlay
        pie.operator('view3d.toggle_shading',         text='',icon='SHADING_SOLID'   ).type      = 'SOLID'                              # ↗ Solid
        pie.operator('view3d.toggle_xray',            text='',icon='XRAY'            )                                                  # ↙ X-ray
        pie.operator('view3d.toggle_shading',         text='',icon='SHADING_RENDERED').type      = 'RENDERED'                           # ↘ Rendered
class VIEW3D_MT_SUBPIE_renderpie(Menu):
    bl_label = ''
    def draw(self,C):
        pie = self.layout.menu_pie()
        pie.separator()                                                                              # ←
        pie.separator()                                                                              # →
        pie.separator()                                                                              # ↓
        pie.separator()                                                                              # ↑
        pie.operator     ('render.render',     text='',icon='OUTLINER_OB_IMAGE').use_viewport = True # ↖ Render image
        pie.operator     ('render.anim_review',text='',icon='MOD_TIME'         )                     # ↗ Render playblast # TODO: fallback to regular viewport render if don't have Anim Review addon.
        op = pie.operator('render.render',     text='',icon='TIME'             )                     # ↙ Render anim
        op.use_viewport = True                                                                       #
        op.animation    = True                                                                       #
        pie.operator     ('render.opengl',     text='',icon='IMAGE_RGB'        )                     # ↘ Render viewport
class VIEW3D_MT_SUBPIE_viewpie(Menu):
    bl_label = ''
    # TODO: candidates to be taken out of their subpies and put here, one level higher: annotation tool, ortho toggle, frame selected, to camera view
    def draw(self,C):
        pie = self.layout.menu_pie()
        pie.separator()                                                                                       # ←
        pie.separator()                                                                                       # →
        pie.operator('wm.call_menu_pie',text='',icon='AREA_SWAP'       ).name = 'VIEW3D_MT_SUBPIE_areapie'    # ↓
        pie.separator()                                                                                       # ↑
        pie.operator('wm.call_menu_pie',text='',icon='RENDER_STILL'    ).name = 'VIEW3D_MT_SUBPIE_renderpie'  # ↖
        pie.operator('wm.call_menu_pie',text='',icon='MATSHADERBALL'   ).name = 'VIEW3D_MT_SUBPIE_shadingpie' # ↗
        pie.operator('wm.call_menu_pie',text='',icon='CON_CAMERASOLVER').name = 'VIEW3D_MT_SUBPIE_camerapie'  # ↙
        pie.separator()                                                                                       # ↘

# -=- Edit Mode -=-
class VIEW3D_OT_set_polyquilt_brush_tool(Operator):
    # TODO: Hm... see set_selection_tool() and consider if these two ops could be combined into one general varargs tool-setting op? Even though it would make calling it in pie menu definitions require multiple lines, it might be clearer.
    bl_idname = 'view3d.set_polyquilt_brush_tool'
    bl_label = ''
    brush_type: bpy.props.StringProperty()
    def execute(self,C):
        bpy.ops.wm.tool_set_by_id(name='mesh_tool.poly_quilt_brush')
        tool = C.workspace.tools.from_space_view3d_mode(C.mode, create=False)
        props = tool.operator_properties('mesh.poly_quilt')
        props.brush_type = self.brush_type
        return {'FINISHED'}
class VIEW3D_OT_set_bevel_tool(Operator):
    # TODO: Hm... see set_selection_tool() and consider if these two ops could be combined into one general varargs tool-setting op? Even though it would make calling it in pie menu definitions require multiple lines, it might be clearer.
    bl_idname = 'view3d.set_bevel_tool'
    bl_label = ''
    affect: bpy.props.StringProperty()
    def execute(self,C):
        bpy.ops.wm.tool_set_by_id(name='builtin.select', as_fallback=True)
        bpy.ops.wm.tool_set_by_id(name='builtin.bevel')
        tool = C.workspace.tools.from_space_view3d_mode(C.mode, create=False)
        props = tool.operator_properties('mesh.bevel')
        props.affect = self.affect
        if self.affect=='VERTICES': bpy.ops.mesh.select_mode(type='VERT')
        else                      : bpy.ops.mesh.select_mode(type='EDGE')
        return {'FINISHED'}
class VIEW3D_OT_select_knife_tool_then_spawn_edit_toolpie(Operator):
    bl_idname = 'view3d.select_knife_tool_then_spawn_edit_toolpie'
    bl_label = ''
    def execute(self,C):
        bpy.ops.wm.tool_set_by_id(name='builtin.knife')
        bpy.ops.wm.call_menu_pie(name='VIEW3D_MT_SUBPIE_edit_toolpie')
        return {'FINISHED'}
class VIEW3D_MT_SUBPIE_edit_markpie(Menu):
    bl_label = ''
    def draw(self,C):
        pie = self.layout.menu_pie()
        pie.operator('mesh.select_mode',         text='Vert'     ).type = 'VERT' # ←
        pie.operator('mesh.mark_seam',           text='Seam'     ).clear = False # →
        pie.separator()#pie.operator('mesh.mark_bevel',          text='Bevel'    ).clear = False # ↓
        pie.operator('mesh.select_mode',         text='Face'     ).type = 'FACE' # ↑
        pie.operator('mesh.select_mode',         text='Edge'     ).type = 'EDGE' # ↖
        pie.operator('mesh.mark_sharp',          text='Sharp'    ).clear = False # ↗
        pie.separator()#pie.operator('mesh.mark_crease',         text='Crease'   ).clear = False # ↙
        pie.operator('mesh.mark_freestyle_edge', text='Freestyle').clear = False # ↘
class VIEW3D_MT_SUBPIE_edit_toolpie(Menu):
    bl_label = ''
    def draw(self,C):
        pie = self.layout.menu_pie()
        pie.operator('wm.tool_set_by_id',     text='Loop Cut'      ).name   = 'builtin.loop_cut'              # ←
        pie.operator('view3d.set_polyquilt_brush_tool', text='PQ Move').brush_type = 'MOVE'                   # → # TODO maybe just do a sculptmode switch instead of PolyQuilt, w/ global var set s.t. next time you open pie it will still be editmode pie.
        pie.operator('wm.tool_set_by_id',     text='Extrude'       ).name   = 'builtin.extrude_region'        # ↓
        pie.operator('wm.tool_set_by_id',     text='PQ Edgeloop'   ).name   = 'mesh_tool.poly_quilt_edgeloop' # ↑
        pie.operator('view3d.set_bevel_tool', text='Bevel'         ).affect = 'EDGES'                         # ↖
        pie.operator('wm.tool_set_by_id',     text='PQ Delete'     ).name   = 'mesh_tool.poly_quilt_delete'   # ↗
        pie.separator() # ↙
        pie.operator('view3d.set_polyquilt_brush_tool', text='PQ Smooth').brush_type = 'SMOOTH'               # ↘ # TODO maybe just do a sculptmode switch instead of PolyQuilt, w/ global var set s.t. next time you open pie it will still be editmode pie.
class VIEW3D_MT_SUBPIE_edit_miscpie(Menu):
    bl_label = ''
    def draw(self,C):
        pie = self.layout.menu_pie()
        pie.operator('mesh.fill_grid',         text='Grid Fill'  ) # ←
        pie.operator('mesh.bridge_edge_loops', text='Bridge'     ) # →
        pie.operator('mesh.edge_face_add',     text='Fill'       ) # ↓
        pie.operator('mesh.subdivide',         text='Subdivide'  ) # ↑
        pie.operator('mesh.remove_doubles',    text='By Distance') # ↖
        pie.operator('mesh.rip_move',          text='Rip'        ) # ↗
        pie.operator('mesh.poke',              text='Poke'       ) # ↙
        pie.operator('wm.tool_set_by_id',      text='Bisect'     ).name = 'builtin.bisect' # ↘

# -=- Sculpt Mode -=-
# -=- Groom Mode -=-
class VIEW3D_OT_select_endpoints(Operator):
    bl_idname = 'view3d.select_endpoints'
    bl_label = ''
    def execute(self,C):
        bpy.ops.curves.set_selection_domain(domain='POINT')
        bpy.ops.curves.select_ends()
        return {'FINISHED'}

# -=- Draw Mode -=-
# -=- Texture Paint Mode -=-
# -=- Weight Paint Mode -=-
# -=- VSE -=-
# -=- TODO etc etc.-=-

# === Main 3D Pie ===
class VIEW3D_MT_PIE_mypie(Menu):
    bl_label = 'My Pie 3D'
    def draw(self,C):
        pie = self.layout.menu_pie()
        if C.mode=='EDIT_MESH':
            pie.operator('view3d.select_knife_tool_then_spawn_edit_toolpie', text='Tool')                       # ← Edit mode tools
            pie.operator('view3d.select_tf_tool_then_spawn_orientpie',     text='Transform')                    # → Transform
            pie.operator('wm.call_menu_pie',text='',icon='RESTRICT_VIEW_ON').name = 'VIEW3D_MT_SUBPIE_viewpie'  # ↓ View options
            pie.operator('wm.call_menu_pie', text='Mode').name = 'VIEW3D_MT_object_mode_pie'                    # ↑ Mode
            pie.operator('wm.call_menu_pie', text='Mark').name = 'VIEW3D_MT_SUBPIE_edit_markpie'                # ↖
            pie.operator('wm.call_menu_pie', text='Hist').name = 'VIEW3D_MT_SUBPIE_historypie'                  # ↗ Undo & more
            pie.operator('wm.call_menu_pie', text='Misc').name = 'VIEW3D_MT_SUBPIE_edit_miscpie'                # ↙
            pie.operator('view3d.select_circle_tool_then_spawn_selectionpie1', text='Circle')                   # ↘ Selection
        if C.mode=='EDIT_CURVE':
            pie.separator()                                                                                     # ←
            pie.operator('view3d.select_tf_tool_then_spawn_orientpie',   text='Transform')                      # → Transform
            pie.operator('wm.call_menu_pie',text='',icon='RESTRICT_VIEW_ON').name = 'VIEW3D_MT_SUBPIE_viewpie'  # ↓ View options
            pie.operator('wm.call_menu_pie', text='Mode').name = 'VIEW3D_MT_object_mode_pie'                    # ↑ Mode
            pie.separator()                                                                                     # ↖
            pie.operator('wm.call_menu_pie', text='Hist').name = 'VIEW3D_MT_SUBPIE_historypie'                  # ↗ Undo & more
            pie.separator()                                                                                     # ↙
            pie.operator('view3d.select_circle_tool_then_spawn_selectionpie1', text='Circle')                   # ↘ Selection
        if C.mode=='SCULPT_CURVES': # A.K.A. Groom
            pie.operator('view3d.select_endpoints')                                                             # ←
            pie.separator('particle.brush_pie_menu', text='3DHB Pie')                                           # →
            pie.operator('wm.call_menu_pie',text='',icon='RESTRICT_VIEW_ON').name = 'VIEW3D_MT_SUBPIE_viewpie'  # ↓ View options
            pie.operator('wm.call_menu_pie', text='Mode').name = 'VIEW3D_MT_object_mode_pie'                    # ↑ Mode
            pie.separator('sculpt_curves.select_grow')                                                          # ↖
            pie.operator('wm.call_menu_pie', text='Hist').name = 'VIEW3D_MT_SUBPIE_historypie'                  # ↗ Undo & more
            pie.separator('curves.select_all').action = 'INVERT'                                                # ↙
            pie.separator('sculpt_curves.min_distance_edit')                                                    # ↘
        if C.mode=='EDIT_ARMATURE':
            pie.separator()                                                                                     # ←
            pie.operator('view3d.select_tf_tool_then_spawn_orientpie', text='Transform')                        # → Transform
            pie.operator('wm.call_menu_pie',text='',icon='RESTRICT_VIEW_ON').name = 'VIEW3D_MT_SUBPIE_viewpie'  # ↓ View options
            pie.operator('wm.call_menu_pie', text='Mode').name = 'VIEW3D_MT_object_mode_pie'                    # ↑ Mode
            pie.separator()                                                                                     # ↖
            pie.operator('wm.call_menu_pie', text='Hist').name = 'VIEW3D_MT_SUBPIE_historypie'                  # ↗ Undo & more
            pie.separator()                                                                                     # ↙
            pie.operator('view3d.select_circle_tool_then_spawn_selectionpie1', text='Circle')                   # ↘ Selection
        if C.mode=='OBJECT':
            pie.separator()                                                                                     # ←
            pie.operator('view3d.select_tf_tool_then_spawn_orientpie', text='Transform')                        # → Transform
            pie.operator('wm.call_menu_pie',text='',icon='RESTRICT_VIEW_ON').name = 'VIEW3D_MT_SUBPIE_viewpie'  # ↓ View options
            pie.operator('wm.call_menu_pie', text='Mode').name = 'VIEW3D_MT_object_mode_pie'                    # ↑ Mode
            pie.operator('wm.save_mainfile',icon='FILE_TICK')                                                   # ↖ Save
            pie.operator('wm.call_menu_pie', text='Hist').name = 'VIEW3D_MT_SUBPIE_historypie'                  # ↗ Undo & more
            pie.operator('animation.time_scrub')                                                                # ↙ Playback # TODO: support regular kf subpie if GPTools not installed
            pie.operator('view3d.select_circle_tool_then_spawn_selectionpie1', text='Circle')                   # ↘ Selection
        if C.mode=='SCULPT':
            pie.operator('wm.call_asset_shelf_popover', text='Brushes').name = 'VIEW3D_AST_brush_sculpt'        # ← Brushes
            pie.separator()                                                                                     # →
            pie.operator('wm.call_menu_pie',text='',icon='RESTRICT_VIEW_ON').name = 'VIEW3D_MT_SUBPIE_viewpie'  # ↓ View options
            pie.operator('wm.call_menu_pie', text='Mode').name = 'VIEW3D_MT_object_mode_pie'                    # ↑ Mode
            pie.operator('wm.save_mainfile',icon='FILE_TICK')                                                   # ↖ Save
            pie.operator('wm.call_menu_pie', text='Hist').name = 'VIEW3D_MT_SUBPIE_historypie'                  # ↗ Undo & more
            pie.separator()                                                                                     # ↙
            pie.separator()                                                                                     # ↘
        if C.mode=='POSE':
            # TODO: add playback play/pause
            pie.separator()                                                                                     # ←
            pie.operator('view3d.select_tf_tool_then_spawn_orientpie', text='Transform')                        # → Transform
            pie.operator('wm.call_menu_pie',text='',icon='RESTRICT_VIEW_ON').name = 'VIEW3D_MT_SUBPIE_viewpie'  # ↓ View options
            pie.operator('wm.call_menu_pie', text='Mode').name = 'VIEW3D_MT_object_mode_pie'                    # ↑ Mode
            pie.separator()                                                                                     # ↖
            pie.operator('wm.call_menu_pie', text='Hist').name = 'VIEW3D_MT_SUBPIE_historypie'                  # ↗ Undo & more
            pie.operator('animation.time_scrub')                                                                # ↙ Playback # TODO: support regular kf subpie if GPTools not installed
            pie.separator()                                                                                     # ↘
        if C.mode=='PAINT_VERTEX':
            pie.separator()                                                                                     # ←
            pie.separator()                                                                                     # →
            pie.operator('wm.call_menu_pie',text='',icon='RESTRICT_VIEW_ON').name = 'VIEW3D_MT_SUBPIE_viewpie'  # ↓ View options
            pie.operator('wm.call_menu_pie', text='Mode').name = 'VIEW3D_MT_object_mode_pie'                    # ↑ Mode
            pie.separator()                                                                                     # ↖
            pie.operator('wm.call_menu_pie', text='Hist').name = 'VIEW3D_MT_SUBPIE_historypie'                  # ↗ Undo & more
            pie.separator()                                                                                     # ↙
            pie.separator()                                                                                     # ↘
        if C.mode=='PAINT_WEIGHT':
            pie.separator()                                                                                     # ←
            pie.separator()                                                                                     # →
            pie.operator('wm.call_menu_pie',text='',icon='RESTRICT_VIEW_ON').name = 'VIEW3D_MT_SUBPIE_viewpie'  # ↓ View options
            pie.operator('wm.call_menu_pie', text='Mode').name = 'VIEW3D_MT_object_mode_pie'                    # ↑ Mode
            pie.separator()                                                                                     # ↖
            pie.operator('wm.call_menu_pie', text='Hist').name = 'VIEW3D_MT_SUBPIE_historypie'                  # ↗ Undo & more
            pie.separator()                                                                                     # ↙
            pie.separator()                                                                                     # ↘
        if C.mode in ['PAINT_GPENCIL','PAINT_GREASE_PENCIL']:
            # TODO: add stuff from Samuel Bernou's addons GPShaper and GPTransform?
            # TODO: add playback play/pause
            pie.separator()                                                                                     # ←
            pie.separator()                                                                                     # →
            pie.operator('wm.call_menu_pie',text='',icon='RESTRICT_VIEW_ON').name = 'VIEW3D_MT_SUBPIE_viewpie'  # ↓ View options
            pie.operator('wm.call_menu_pie', text='Mode').name = 'VIEW3D_MT_object_mode_pie'                    # ↑ Mode
            pie.separator()                                                                                     # ↖
            pie.operator('wm.call_menu_pie', text='Hist').name = 'VIEW3D_MT_SUBPIE_historypie'                  # ↗ Undo & more
            pie.operator('animation.time_scrub')                                                                # ↙ # TODO: support regular kf subpie if GPTools not installed
            pie.separator()                                                                                     # ↘
        if C.mode in ['EDIT_GPENCIL','EDIT_GREASE_PENCIL']:
            pie.separator()                                                                                     # ←
            pie.operator('view3d.select_tf_tool_then_spawn_orientpie', text='Transform')                        # → Transform
            pie.operator('wm.call_menu_pie',text='',icon='RESTRICT_VIEW_ON').name = 'VIEW3D_MT_SUBPIE_viewpie'  # ↓ View options
            pie.operator('wm.call_menu_pie', text='Mode').name = 'VIEW3D_MT_object_mode_pie'                    # ↑ Mode
            pie.separator()                                                                                     # ↖
            pie.operator('wm.call_menu_pie', text='Hist').name = 'VIEW3D_MT_SUBPIE_historypie'                  # ↗ Undo & more
            pie.separator()                                                                                     # ↙
            pie.separator()                                                                                     # ↘
        if C.mode in ['SCULPT_GPENCIL','SCULPT_GREASE_PENCIL']:
            pie.separator()                                                                                     # ←
            pie.separator()                                                                                     # →
            pie.operator('wm.call_menu_pie',text='',icon='RESTRICT_VIEW_ON').name = 'VIEW3D_MT_SUBPIE_viewpie'  # ↓ View options
            pie.operator('wm.call_menu_pie', text='Mode').name = 'VIEW3D_MT_object_mode_pie'                    # ↑ Mode
            pie.separator()                                                                                     # ↖
            pie.operator('wm.call_menu_pie', text='Hist').name = 'VIEW3D_MT_SUBPIE_historypie'                  # ↗ Undo & more
            pie.separator()                                                                                     # ↙
            pie.separator()                                                                                     # ↘
        if C.mode in ['WEIGHT_GPENCIL','WEIGHT_GREASE_PENCIL']:
            pie.separator()                                                                                     # ←
            pie.separator()                                                                                     # →
            pie.operator('wm.call_menu_pie',text='',icon='RESTRICT_VIEW_ON').name = 'VIEW3D_MT_SUBPIE_viewpie'  # ↓ View options
            pie.operator('wm.call_menu_pie', text='Mode').name = 'VIEW3D_MT_object_mode_pie'                    # ↑ Mode
            pie.separator()                                                                                     # ↖
            pie.operator('wm.call_menu_pie', text='Hist').name = 'VIEW3D_MT_SUBPIE_historypie'                  # ↗ Undo & more
            pie.separator()                                                                                     # ↙
            pie.separator()                                                                                     # ↘
        if C.mode in ['VERTEX_GPENCIL','VERTEX_GREASE_PENCIL']:
            pie.separator()                                                                                     # ←
            pie.separator()                                                                                     # →
            pie.operator('wm.call_menu_pie',text='',icon='RESTRICT_VIEW_ON').name = 'VIEW3D_MT_SUBPIE_viewpie'  # ↓ View options
            pie.operator('wm.call_menu_pie', text='Mode').name = 'VIEW3D_MT_object_mode_pie'                    # ↑ Mode
            pie.separator()                                                                                     # ↖
            pie.operator('wm.call_menu_pie', text='Hist').name = 'VIEW3D_MT_SUBPIE_historypie'                  # ↗ Undo & more
            pie.operator('animation.time_scrub')                                                                # ↙ # TODO: support regular kf subpie if GPTools not installed
            pie.separator()                                                                                     # ↘


# === Main Nodeview Pie ===
# TODO: add viewernode. Cut links. Delete. Mute (maybe mute links too).
class NODE_MT_PIE_mypie(Menu):
    bl_label = 'My Pie 2D'
    def draw(self,C):
        pie = self.layout.menu_pie()
        pie.operator('wm.call_menu', text='', icon='ADD').name = 'NODE_MT_add'                              # ←
        pie.separator()                                                                                     # →
        pie.operator('wm.call_menu_pie',text='',icon='RESTRICT_VIEW_ON').name = 'VIEW3D_MT_SUBPIE_viewpie'  # ↓ View options
        pie.separator()                                                                                     # ↑
        pie.separator()                                                                                     # ↖
        pie.operator('wm.call_menu_pie', text='Hist').name = 'VIEW3D_MT_SUBPIE_historypie'                  # ↗ Undo & more
        pie.operator('wm.save_mainfile', text='', icon='FILE_TICK')                                         # ↙
        pie.separator()                                                                                     # ↘

# === Main Dopesheet Pie ===
class DOPESHEET_MT_PIE_mypie(Menu):
    bl_label = 'My Pie Dopesheet'
    def draw(self,C):
        # TODO: add play/pause
        pie.separator()                                                                                     # ←
        pie.separator()                                                                                     # →
        pie.operator('wm.call_menu_pie',text='',icon='RESTRICT_VIEW_ON').name = 'VIEW3D_MT_SUBPIE_viewpie'  # ↓ View options
        pie.separator()                                                                                     # ↑ Dopesheet vs. Action vs. action editor vs. gp editor modes etc.?
        pie.separator()                                                                                     # ↖
        pie.operator('wm.call_menu_pie', text='Hist').name = 'VIEW3D_MT_SUBPIE_historypie'                  # ↗ Undo & more
        pie.operator('animation.time_scrub')                                                                # ↙ # TODO: support regular kf subpie if GPTools not installed
        pie.separator()                                                                                     # ↘

# === Global modal ===
# I have a crazy modal operator always running so that I have FULL CONTROL over all inputs received.
# This way I can do cool stuff like use mouse buttons as modifiers, test if two buttons were pressed near the same time, etc..
# TODO: selection brush in groom mode on drag ↖, just like circle select in other modes.
class KeyStatus():
    def __init__(self):
        self.held              = False
        self.ul_flag           = False
        self.drag_dist         = 0
        self.last_pressed_pos  = (0,0)
        self.last_pressed_time = 0
        self.pressed_pos       = (0,0)
        self.pressed_time      = 0
def current_area_and_region(C,mouse_x,mouse_y):
    for area in C.window.screen.areas:
        if area.x <= mouse_x <= area.x+area.width and area.y <= mouse_y <= area.y+area.height:
            for region in area.regions:
                if region.width > 1 and region.height > 1 and region.x <= mouse_x <= region.x+region.width and region.y <= mouse_y <= region.y+region.height:
                    return area,region
    return None,None
class BINGUS_OT_mymodal(Operator):
    bl_idname = 'hello.mymodal'
    bl_label = 'My Modal'
    bl_options = {'REGISTER','MODAL_PRIORITY'}

    keystats         = {i.identifier: KeyStatus() for i in bpy.types.Event.bl_rna.properties['type'].enum_items}
    ul_flag          = False
    invert_flag      = False
    prev_tool_nm     = None
    area             = None
    region           = None
    prev_area_type   = ''
    target = None

    def invoke(self,C,ev):
        C.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self,C,ev):
        if ev.type not in ['V','LEFTMOUSE','RIGHTMOUSE','MIDDLEMOUSE','BUTTON4MOUSE','BUTTON5MOUSE','MOUSEMOVE','INBETWEEN_MOUSEMOVE']: return {'PASS_THROUGH'} #TMP

        active_tool_nm = C.workspace.tools.from_space_view3d_mode(C.mode).idname
        running_modals = [op.bl_idname for op in C.window.modal_operators]
        busy_modal = any(m in running_modals for m in ['FLOW_NAVIGATION_OT_hold_navigation', 'SCULPT_CURVES_OT_brush_stroke', 'CURVES_OT_brush3d_edit', 'VIEW3D_OT_select_circle'])
        print(running_modals)

        K = self.keystats
        # Can always detect PRESS, but sometimes RELEASE gets ate by checkboxes, sliders, etc..
        # To get around this, just set .held to False whenever mouse hovers over a new area.
        prev_area_type = self.area.type if self.area else ''
        self.area, self.region = current_area_and_region(C,ev.mouse_x,ev.mouse_y)
        if self.area and prev_area_type != self.area.type: K[ev.type].held = False
        if ev.value == 'PRESS':
            K[ev.type].held              = True
            K[ev.type].drag_dist         = 0
            K[ev.type].last_pressed_pos  = K[ev.type].pressed_pos
            K[ev.type].last_pressed_time = K[ev.type].pressed_time
            K[ev.type].     pressed_pos  = (ev.mouse_x,ev.mouse_y)
            K[ev.type].     pressed_time = time.monotonic()
        if K['LEFTMOUSE'].held and self.ul_flag:
            dx = ev.mouse_x - K['LEFTMOUSE'].pressed_pos[0]
            dy = ev.mouse_y - K['LEFTMOUSE'].pressed_pos[1]
            K['LEFTMOUSE'].drag_dist = sqrt(dx*dx+dy*dy)
            self.ul_flag   = (atan2(dy,dx) > pi*4.5/8) and (atan2(dy,dx) < pi*7.5/8) or (dx<5 and dy>-5 and K['LEFTMOUSE'].drag_dist<8)
        if K[ 'RIGHTMOUSE' ].held:
            dx = ev.mouse_x - K['RIGHTMOUSE'].pressed_pos[0]
            dy = ev.mouse_y - K['RIGHTMOUSE'].pressed_pos[1]
            K[ 'RIGHTMOUSE' ].drag_dist = sqrt(dx*dx+dy*dy)
        if K['BUTTON4MOUSE'].held:
            dx = ev.mouse_x - K['BUTTON4MOUSE'].pressed_pos[0]
            dy = ev.mouse_y - K['BUTTON4MOUSE'].pressed_pos[1]
            K['BUTTON4MOUSE'].drag_dist = sqrt(dx*dx+dy*dy)
        if ev.value == 'RELEASE':
            K[ev.type].held = False
            if ev.type=='LEFTMOUSE': self.ul_flag = False
        if K['LEFTMOUSE'].held and K['RIGHTMOUSE'].held and (K['LEFTMOUSE'].pressed_time - K['RIGHTMOUSE'].pressed_time < 0.1): self.invert_flag = True
        if not K['RIGHTMOUSE'].held: self.invert_flag = False
        if not K['RIGHTMOUSE'].held and not K['LEFTMOUSE'].held:
            if self.prev_tool_nm: bpy.ops.wm.tool_set_by_id(name=self.prev_tool_nm)
            self.prev_tool_nm = None

        # TMP
        with C.temp_override(region=self.region,area=self.area):
            for k,v in self.keystats.items():
                if k in ['BUTTON4MOUSE']:
                    print(ev.mouse_region_x)
                    #print('(',ev.type,ev.value,')','held',k,v.held,'ul',v.ul_flag,'invert',self.invert_flag)#,'presspos',v.pressed_pos,'presstime',v.pressed_time)
        #print(self.invert_flag)
        if self.area and self.region: print(self.area.type,self.region.type)

        # Pie
        if not self.invert_flag and K['RIGHTMOUSE'].held and K['RIGHTMOUSE'].drag_dist > C.preferences.inputs.drag_threshold:
            K['RIGHTMOUSE'].held = False # Pie eats the release event so gotta unset it manually.
            bpy.ops.wm.call_menu_pie(name='VIEW3D_MT_PIE_mypie')

        # Nav
        if ev.type=='BUTTON4MOUSE' and ev.value=='PRESS':# and self.area and self.area.type=='VIEW_3D' and self.region.type=='WINDOW': # TODO: Sucks that the VIEW_3D UI empty space still counts and blocks my orbit. OH! Maybe automatically collapse sidepanel while doing the 3d window orbit, and auto-open it back up when concluding? Oh, that wold only solve half the problem...
            # BUG: if you don't star the modal in 3d view, then it will always target 0,0,0. Why?
            # BECAUSE: ev.mouse_region_x is dependent on the region you started the modal in. So you need to start it in the view3d window for the mouse coords to be appropriate.
            # The view2d pans are working fine b/c they only depend on dx or dy, not the exact mouse position in region like this raycast does. Soo......
            # The solution to this would be to Make an input watcher like flownav that only procs the nav modal on buttonpress, so that the context is simply whereever the mouse is when the MB4 was pressed, no temp_override() needed.
            #   This would also finally let me implement cursor capture, s.t. cursor doesn't go over the edges of areas and cause confusion.
            # But for now, I can just be careful to start my modal in VIEW_3D WINDOW only, and prolly not move the view3d window either. O/w 3dview raycasting won't work.
            if self.area.type=='VIEW_3D': # I.e. if self.area.spaces[0].region_3d exists.
                origin    = view3d_utils.region_2d_to_origin_3d(self.region, self.area.spaces[0].region_3d, (ev.mouse_region_x,ev.mouse_region_y))
                direction = view3d_utils.region_2d_to_vector_3d(self.region, self.area.spaces[0].region_3d, (ev.mouse_region_x,ev.mouse_region_y))
                is_hit, hit_pos, hit_norm, idx, hit_obj, mtx = C.scene.ray_cast(C.evaluated_depsgraph_get(), origin, direction)
                if not is_hit: self.target = Vector((0,0,0)) #C.region_data.view_location + (C.region_data.view_rotation @ Vector((0,0,-1))) * C.region_data.view_distance
                else         : self.target = hit_pos.copy()
            return {'RUNNING_MODAL'}
        if K['BUTTON4MOUSE'].held and self.area:
            dx = ev.mouse_x - ev.mouse_prev_x
            dy = ev.mouse_y - ev.mouse_prev_y
            if not (self.area.type=='VIEW_3D' and self.region.type=='WINDOW'):
                with C.temp_override(region=self.region,area=self.area): # TODO crashes if cursor leaves region while LMB held ("incorrect context" complaint, though only affects the zoom fxns, not pan). To fix, either split into separate modal which captures mouse (better), or only context override once at start on mb4 press.
                    if K['LEFTMOUSE'].held:
                        if dx>0: bpy.ops.view2d.zoom_in(zoomfacx= 0.001)
                        if dx<0: bpy.ops.view2d.zoom_in(zoomfacx=-0.001)
                        if dy>0: bpy.ops.view2d.zoom_in(zoomfacy= 0.001)
                        if dy<0: bpy.ops.view2d.zoom_in(zoomfacy=-0.001)
                    else: bpy.ops.view2d.pan(deltax=-dx,deltay=-dy)
            if self.area.type=='VIEW_3D' and self.region.type=='WINDOW':
                if not self.target: self.target = Vector((0,0,0))
                rd = self.region.data
                view_x = rd.view_rotation @ Vector((1, 0, 0))
                view_y = rd.view_rotation @ Vector((0, 1, 0))
                view_z = rd.view_rotation @ Vector((0, 0, 1))
                if K['LEFTMOUSE'].held: # LMB held: horizontal = roll, vertical = vertical orbit.
                    if dx:
                        q = Quaternion(view_z, dx*0.01)
                        rd.view_rotation = q @ rd.view_rotation
                    if dy:
                        q = Quaternion(view_x, dy*0.01)
                        rd.view_rotation = q @ rd.view_rotation
                else: # LMB released: horizontal = horizontal orbit, vertical = zoom + gradual pan to center the target in view.
                    if dx:
                        q = Quaternion(view_y, -dx*0.01)
                        rd.view_rotation = q @ rd.view_rotation
                    if dy:
                        factor = max(0.1, 1.0 + -0.01*dy)
                        rd.view_distance = max(0.001, rd.view_distance * factor)
                        t = min(1.0, 0.02*abs(dy))
                        rd.view_location += (self.target - rd.view_location) * t
            self.area.tag_redraw()
            return {'RUNNING_MODAL'}

        # Other stuff
        if C.mode=='EDIT_MESH' and K['LEFTMOUSE'].held and not busy_modal:
            # Cirlce-select shortcut from upper-left drag.
            if self.ul_flag and K['LEFTMOUSE'].drag_dist > C.preferences.inputs.drag_threshold:
                if self.invert_flag: bpy.ops.view3d.select_circle('INVOKE_DEFAULT', mode='SUB')
                else               : bpy.ops.view3d.select_circle('INVOKE_DEFAULT', mode='ADD')
            if ev.type=='LEFTMOUSE' and ev.value=='PRESS':
                if self.invert_flag: bpy.ops.mesh.shortest_path_pick('INVOKE_DEFAULT')
                else               : bpy.ops.view3d.select('INVOKE_DEFAULT',toggle=True)
                if C.preferences.inputs.mouse_double_click_time/1000 > K['LEFTMOUSE'].pressed_time - K['LEFTMOUSE'].last_pressed_time:
                    if self.invert_flag: bpy.ops.mesh.select_all('INVOKE_DEFAULT', action='INVERT')
                    else               : bpy.ops.view3d.select('INVOKE_DEFAULT',deselect_all=True) # This solo-selects unlike mesh.select_all(action='DESELECT')
                return {'RUNNING_MODAL'} # Not PASS_THROUGH, need to eat the keypress or else Blender's default keymaps interfere.
            

        if C.mode=='SCULPT_CURVES' and K['LEFTMOUSE'].held and not busy_modal:
            # Preparatory brush inversion stuff, b/c not all brushes can be inverted as simply as `brush_stroke(mode='INVERT')`.
            #if self.invert_flag:
            #    if active_tool_nm == 'builtin_brush.add':
            #        self.prev_tool_nm = 'builtin_brush.add'
            #        bpy.ops.wm.tool_set_by_id(name='builtin_brush.delete')
            #    if active_tool_nm == 'builtin_brush.delete':
            #        self.prev_tool_nm = 'builtin_brush.delete'
            #        bpy.ops.wm.tool_set_by_id(name='builtin_brush.add')
            #    if active_tool_nm == 'hair_brush_3d.part':
            #        self.prev_tool_nm = 'hair_brush_3d.part'
            #        bpy.ops.wm.tool_set_by_id(name='builtin_brush.attract')
            #    if active_tool_nm == 'hair_brush_3d.attract':
            #        self.prev_tool_nm = 'hair_brush_3d.attract'
            #        bpy.ops.wm.tool_set_by_id(name='builtin_brush.part')
            #    if 'hair_brush_3d' in active_tool_nm:
            #        a = C.scene.hair_brush_3d
            #        a.clone_mode         = 'CLONE_SOURCE' if a.clone_mode=='CLONE_DRAW' else 'CLONE_DRAW' # Clone brush.
            #        a.rotation_direction = 'CCW'          if a.rotation_direction=='CW' else 'CW'         # Twist brush.

            # Selection brush shortcut from upper-left drag.
            if self.ul_flag and K['LEFTMOUSE'].drag_dist > C.preferences.inputs.drag_threshold:
                if active_tool_nm != 'builtin_brush.selection_paint': self.prev_tool_nm = active_tool_nm # So can hold RMB and press LMB a bunch, and still remember the OG brush for when we finally release RMB.
                bpy.ops.wm.tool_set_by_id(name='builtin_brush.selection_paint')
                bpy.ops.wm.context_set_boolean(data_path='space_data.overlay.show_sculpt_curves_cage',value=True)
                if self.invert_flag: bpy.ops.sculpt_curves.brush_stroke('INVOKE_DEFAULT',        mode='INVERT')
                else               : bpy.ops.sculpt_curves.brush_stroke('INVOKE_DEFAULT',brush_toggle='SMOOTH') # For selection brush, smooth means extend-select.

            # Regular, non-selection brushstroke.
            # For add & delete brush, we definitely want instant-activation on LMB press, so we don't wait to detect upper-left dragging.
            if (not self.ul_flag) or active_tool_nm in ['builtin_brush.add','builtin_brush.delete']:
                if 'hair_brush_3d' in active_tool_nm: bpy.ops.curves.brush3d_edit('INVOKE_DEFAULT')
                elif self.invert_flag: bpy.ops.sculpt_curves.brush_stroke('INVOKE_DEFAULT', mode='INVERT')
                else                 : bpy.ops.sculpt_curves.brush_stroke('INVOKE_DEFAULT'               )
        # Post-selectionbrush cleanup.
        if C.mode=='SCULPT_CURVES' and not K['LEFTMOUSE'].held and not self.invert_flag:
            bpy.ops.wm.context_set_boolean(data_path='space_data.overlay.show_sculpt_curves_cage',value=False)

        #if active_tool_nm == 'builtin.transform':
        #    translate_running = "TRANSFORM_OT_translate" in running_modals
        #    trackball_running = "TRANSFORM_OT_trackball" in running_modals
        #    resize_running    = "TRANSFORM_OT_resize"    in running_modals
        #    transform_running = translate_running or trackball_running or resize_running
        #    #if ev.type ==    'LEFTMOUSE' and ev.value ==   'PRESS':
        #    #    if resize_running: return {'FINISHED', 'PASS_THROUGH'}
        #    if     K['LEFTMOUSE'].held and not K['RIGHTMOUSE'].held and not K['BUTTON4MOUSE'].held and not transform_running: bpy.ops.transform.translate('INVOKE_DEFAULT')
        #    if     K['LEFTMOUSE'].held and     K['RIGHTMOUSE'].held and not K['BUTTON4MOUSE'].held and not transform_running: bpy.ops.transform.trackball('INVOKE_DEFAULT')
        #    if not K['LEFTMOUSE'].held and not K['RIGHTMOUSE'].held and     K['BUTTON4MOUSE'].held and not transform_running: bpy.ops.transform.resize   ('INVOKE_DEFAULT')
        #    if not K['LEFTMOUSE'].held and not K['RIGHTMOUSE'].held and not K['BUTTON4MOUSE'].held and not    resize_running: return {'FINISHED', 'PASS_THROUGH'}

        return {'PASS_THROUGH'}

# === Boilerplate ===
all_classes_in_this_file = tuple(
    obj for obj in globals().values()
    if isinstance(obj, type)
    and obj.__module__ == __name__
    and issubclass(obj, (Menu, Operator))
)
KMS = [] # Stores KeyMaps created by this add-on, for easy registering/deregistering.
def register():
    for c in all_classes_in_this_file: bpy.utils.register_class(c)
    wm = bpy.context.window_manager
    global KMS
    if wm.keyconfigs.addon:
        km  = wm.keyconfigs.addon.keymaps.new(name='3D View', space_type='VIEW_3D')
        kmi = km.keymap_items.new('wm.call_menu_pie', 'RIGHTMOUSE', 'PRESS')
        kmi.properties.name = 'VIEW3D_MT_PIE_mypie'
        KMS.append((km,kmi))
        km  = wm.keyconfigs.addon.keymaps.new(name='Node Editor', space_type='NODE_EDITOR')
        kmi = km.keymap_items.new('wm.call_menu_pie', 'RIGHTMOUSE', 'PRESS')
        kmi.properties.name = 'NODE_MT_PIE_mypie'
        KMS.append((km,kmi))
        km  = wm.keyconfigs.addon.keymaps.new(name='Dopesheet', space_type='DOPESHEET_EDITOR')
        kmi = km.keymap_items.new('wm.call_menu_pie', 'RIGHTMOUSE', 'PRESS')
        kmi.properties.name = 'DOPESHEET_MT_PIE_mypie'
        KMS.append((km,kmi))
def unregister():
    for c in all_classes_in_this_file: bpy.utils.unregister_class(c)
    wm = bpy.context.window_manager
    global KMS
    if wm and wm.keyconfigs and wm.keyconfigs.addon: [km.keymap_items.remove(kmi) for km,kmi in KMS]
    KMS.clear()
if __name__ == '__main__': register()
